#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//double linked list for creating a program required for an online electronic devices store

struct Node {
    int id;
    int min_quantity;
    char name[255];
    char category[255];
    struct Node *next;  //Pointer to the next node
    struct Node *prev;  //Pointer to the previous node
};

struct Node* head = NULL;

void add_component(int id, int min_quantity, char* name, char* category) {
    struct Node* new_node = (struct Node*) malloc(sizeof(struct Node)); //Allocation of node
    //We put the data from the node
    new_node->id = id;
    new_node->min_quantity = min_quantity;
    strcpy(new_node->name, name);
    strcpy(new_node->category, category);
    //the previous node is set to be NULL and we make the next of the newly created node as head
    new_node->prev = NULL;
    new_node->next = head;
    if(head != NULL) {
        head->prev = new_node;
    }   // change the prev of head node to the new node
    head = new_node;
}

void display_min_quantity(char* name) {
    struct Node* current = head;
    while(current != NULL) {
        if(strcmp(current->name, name) == 0) {
            printf("Minimum purchase quantity for %s: %d\n", current->name, current->min_quantity);
            return;
        }
        current = current->next;    //goes through the following node
    }
    printf("Component not found\n");    // if the user(client) enters an invalid value, this message is displayed
} //This function retains the information about the minimum quantity and displays this value, being dependent on the current name

void display_all_components() {
    struct Node* current = head;
    while(current != NULL) {
        printf("ID: %d, Name: %s\n", current->id, current->name);
        current = current->next;
    }
}   //this functions retains information about the id of the component and its name

void display_components_by_category(char* category) {
    struct Node* current = head;
    int count=0;
    while(current != NULL) {
        if (strcmp(current->category, category) == 0) {
            printf("Component name: %s\n", current->name);
            count=1;
        }
        current = current->next; //goes through the following node
    }
    if(count==0)
     printf("Category not found\n"); // if the user(client) enters an invalid value, this message is displayed
}
//int main function
int main() {
    int choice;
    //inseration of all electronic components available in the online store
    add_component(22, 10, "Resistor", "Passive_elements");
    add_component(21, 100, "Capacitor", "Passive_elements");
    add_component(20, 1000, "Diode", "Semiconductors");
    add_component(19, 25, "Coil", "Passive_elements");
    add_component(18, 2, "Thermistor_NTC", "Passive_elements");
    add_component(17, 10, "Relay", "Relay_and_contactors");
    add_component(16, 1, "Microphone", "Sound_source");
    add_component(15, 500, "LED_red", "Light_source");
    add_component(14, 25, "LED_green", "Light_source");
    add_component(13, 100, "LED_yellow", "Light_source");
    add_component(12, 50, "LED_blue", "Light_source");
    add_component(11, 1, "Antenna", "Passive_elements");
    add_component(10, 3, "Programmable_controller", "Robo");
    add_component(9, 25, "Switch", "Switches_and_indicators");
    add_component(8, 25, "Button", "Switches_and_indicators");
    add_component(7, 25, "Transistor", "Semiconductors");
    add_component(6, 10, "Thermistor_PTC", "Passive_elements");
    add_component(5, 1, "Integrated_circuits", "Semiconductors");
    add_component(4, 2, "Audio_telecoil", "Passive_elements");
    add_component(3, 1, "Audio_condenser", "Passive_elements");
    add_component(2, 5, "Frame_control", "Switches_and_indicators");
    add_component(1, 12, "Sensor_module", "Robo");

    char name[255];
    //do...while function that creates a menu with multiple options for the user(client)
    do {
        printf("\n****************************************** Online electronic devices store ******************************************\n\n");
        printf("\n1. Categories of components\n");
        printf("2. Show all components\n");
        printf("3. Search component\n");
        printf("4. Exit\n");

        printf("Choose an option\n");
        scanf("%d", &choice);
        switch (choice) {
            case 1:
                printf("Enter the category you want to search for: \n");
                scanf("%s", name);
                display_components_by_category(name);
                break;
            case 2:
                printf("Here are all the components available:\n");
                display_all_components();
                break;
            case 3:
                printf("Search component was chosen\n");
                printf("What component are you looking for?\n(Enter the name of the product)\n");
                scanf("%s", name);
                display_min_quantity(name);
                break;
            case 4:
                printf("Thank you for visiting our site!\n");
                break;
            default:
                printf("INVALID CHOICE\n");
        }
    }
    while (choice != 4);    //if the user selects another value different from the ones included in the do...while the test "INVALID CHOICE will apear and the user is
    //sent back to the initial menu
    return 0;
}