//including the header files
#include <iostream>
#include <ctime>

using namespace std;

class Library{
protected:
    string library_name; //name of the library
    string library_address;  // address of the library
    int no_books;
public:
    //Setters
    void set_library_name(string u_library_name);
    void set_library_address(string u_library_address);
    void set_no_books(int u_no_books);
    //Getters
    string get_library_name();
    string get_library_address();
    int get_no_books();

    //Constructors
    Library(); //implicit constructor

    Library(string u_library_name, string u_library_address, int u_no_books);

    //Destructor
    ~Library();

}; //base class

class Books : public Library{
protected:

    string book_name; 	// Stores the name of the book
    string author_name; //stores the name of the author
    string type_book; //stores the type of the book
public:

    //Setters
    void set_book_name(string u_book_name);
    void set_author_name(string u_author_name);
    void set_type_book(string u_type_book);

    //Getters
    string get_book_name();
    string get_author_name();
    string get_type_book();

    //Constructors(composed because Books is a derived class from the mase class Library
    Books() : Library(){
        cout << "Implicit Constructor was called (from Books)\n";
        book_name = "Default name";
        author_name = "None";
        type_book = "None";
    }

    Books(string u_library_name, string u_library_address  , int u_no_books ,string u_book_name, string u_author_name,
          string u_type_book) : Library(u_library_name , u_library_address , u_no_books){
        cout << "Constructor with parameters was called (from Books)\n";

        book_name = u_book_name;
        author_name = u_author_name;
        type_book = u_type_book;
    }

    //Destructor
    ~Books(){
        cout << "Destructor was called (Books)\n";
    }

};  //derived class Books

class Customer : public Books{
    //The attributes were kept private as they will be indirectly accessed through the methods.
    //Here protected is not needed as this class has no child

    string name_customer;	// Stores the name of the customer
    int books;		// Stores the number of books of a customer

public:
    //Setters
    void set_name_customer(string u_name_customer);
    void set_books(int u_books);

    //Getters
    string get_name_customer();
    int get_books();

    //Constructors - Again, because of the inheritance the constructors need to be composed
    Customer() : Books(){

        cout << "Implicit Constructor was called (Costumer)\n";

        name_customer = "Default name";
        int books = 0;
    }

    Customer(string u_library_name , string u_library_address, int u_no_books ,string u_book_name, string u_author_name , string u_type_book,
             string u_name_customer,int u_books) : Books(library_name , library_address , no_books , book_name , author_name , type_book){
        cout << "Constructor with parameters was called (from Costumer)\n";

        name_customer = u_name_customer;
        books = u_books;
    }

    //Destructors
    ~Customer(){
        cout << "Destructor was called (Costumer)\n";
    };

    //Methods
    bool pay_fine(){
        srand(time(NULL));
        int random_number = rand() % 100 + 1; //random number between 1 and 100
        if(random_number < 30)
        {
            return 1; //no need to pay a fee
        }
        else
        {
            return 0; //you need to pay
        }
    }   // This methods allows us to percepe a fine for the costumer if he did not returned the books he borrowed (1 - no need to pay, 0 - needs to pay for the books)

    void return_book(){
        if(no_books == 0){
            cout << "This customer has no books to return";
            return ; // We exit the function
        }
        if(pay_fine() == 1){
            cout << "Thank you for taking the books back in time";
            no_books--;
        }
        else{
            cout << "You are late with your return you will need to pay a fine";
            no_books--;
        }
    }

    void add_books(int new_number){
        set_no_books(no_books + new_number);
    }

}; //second derived class but this class is derived from Books

// ******************************************** Library methods definition ********************************************
void Library :: set_library_name(string u_library_name){
    library_name = u_library_name;
}
void Library :: set_library_address(string u_library_address){
    library_address = u_library_address;
}
void Library :: set_no_books(int u_no_books){
    no_books = u_no_books;
}
string Library :: get_library_name(){
    return library_name;
}
string Library :: get_library_address(){
    return library_address;
}
int Library :: get_no_books(){
    return no_books;
}
Library :: Library(){
    cout << "Implicit Constructor was called (Library)\n";
    library_name = "None";
    library_address = "Bucharest";
    no_books = 0;
}
Library :: Library(string u_library_name, string u_library_address, int u_no_books) {
    cout << "Constructor with parameters was called (Library)\n";
        library_name = u_library_name;
        library_address = u_library_address;
        no_books = u_no_books;
}
Library :: ~Library() {
    cout << "Destructor was called (Library)\n";
}
// ******************************************** Books methods definition ********************************************
void Books :: set_book_name(string u_book_name){
    book_name = u_book_name;
}
void Books :: set_author_name(string u_author_name){
    author_name = u_author_name;
}
void Books :: set_type_book(string u_type_book){
    type_book = u_type_book;
}
string Books :: get_book_name(){
    return book_name;
}
string Books :: get_author_name(){
    return author_name;
}
string Books :: get_type_book(){
    return type_book;
}
// ******************************************** Customer methods definition ********************************************
void Customer :: set_name_customer(string u_name_customer){
    name_customer = u_name_customer;
}
void Customer :: set_books(int u_books){
    books = u_books;
}
string Customer :: get_name_customer() {
    return name_customer;
}
int Customer ::get_books() {
    return books;
}

int main(){
    int n, selection_1, selection_2, books, badge = 0, badge_1 = 0, badge_2 = 0;
    string library, address, client;

    cout << "\n   *********************************************************************************************************************\n";
    cout << "\n   ******************************************** Welcome to the virtual library *****************************************\n";
    cout << "\n   *********************************************************************************************************************\n";

    cout << "\n What is the maximum number of customers in the library?: ";
    cin >> n;
    Customer customer[n];

    do{

        cout << "\n Choose from the following options: \n" << endl;

        cout << "1. Instructions" << endl;
        cout << "2. Create infrastructure" << endl;
        cout << "3. View customers data" << endl;
        cout << "4. Actions " << endl;
        cout << "5. Exit " << endl;

        int input = 0; //Used to check the option input

        do{

            cout << "Enter here your selection: ";
            cin >> selection_1;

            if(selection_1 == 1 || selection_1 == 2 || selection_1 == 3 || selection_1 == 4 || selection_1 == 5){
                input = 1;
            }

        }while(input == 0);

        //Selection 1: Instructions
        if(selection_1 == 1){

            cout << "\n  ******************************************** Instructions ******************************************** \n" << endl;

            cout << "This program represents a basic application for managing the customers in a library. " << endl;
            cout << "In the beginning the user is prompted with some basic options to choose from. " << endl;
            cout << "The selections are done by entering the corresponding number and pressing enter.\n" << endl;

            cout << "In the beginning one has to create the infrastructure using the option number 2. "<< endl;
            cout << "It will ask for general data and will allow the user to input the customer's names independently." << endl;
            cout << "Once the information is in place, we can go back to the main menu and either visualize the data" << endl;
            cout << " or select actions. Among those, the user can add new books to a customer via his badge number," << endl;
            cout << " or return books." << endl;

            cout << "\nWarning: The program is not protected against non-expected outputs! " << endl;

            //Waiting sequence
            int back_instructions = 0;

            do{

                cout << "\nPress any number to go back: ";
                cin >> back_instructions;

            }while(back_instructions == 0);

        }
        //Selection 2: Create infrastructure
        if(selection_1 == 2){

            cout << "\n  ******************************************** Create infrastructure ********************************************\n" << endl;

            cout << "\nLibrary name: ";
            cin >> library;

            cout << "Library address: ";
            cin >> address;

            for(int i = 0; i < n; i++){

                cout << "Customer:";
                cin >> client;

                customer[i].set_library_name(library);
                customer[i].set_library_address(address);
                customer[i].set_no_books(0);

                customer[i].set_name_customer(client);
            }

            int back_infrastructure = 0;

            do{

                cout << "Press any number to go back: ";
                cin >> back_infrastructure;

            }while(back_infrastructure == 0);

        }

        //Selection 2: View customers data
        if(selection_1 == 3){

            cout << "\n   ******************************************** View department data ********************************************\n" << endl;

            cout << "General info " << endl;
            cout << "The name of the library: " << customer[0].get_library_name() << endl;
            cout << "The address of the library: " << customer[0].get_library_address() << endl;

            cout << "\n Customers options \n" << endl;

            for(int i = 0; i < n; i++){

                cout << "Customer's Number: " << i << endl;		//His index
                cout << "Name: " << customer[i].get_name_customer() << endl;
                cout << "Books: " << customer[i].get_no_books() << endl;
                cout << endl;
            }

            //Waiting sequence
            int back_view_data = 0;

            do{

                cout << "\n Press any number to go back: ";
                cin >> back_view_data;

            }while(back_view_data == 0);

        }

        //Selection 4
        if(selection_1 == 4){

            selection_2 = 0;

            cout << "\n  ********************************************  Actions ********************************************\n" << endl;

            do{

                cout << "Choose one of the following actions: \n" << endl;

                cout << "1. Receive a new book" << endl;
                cout << "2. Return book" << endl;
                cout << "3. Back to main menu" << endl;

                cout << "Enter here your selection: ";
                cin >> selection_2;

                if(selection_2 == 1){

                    cout << "Number of books to be received: ";
                    cin >> books;

                    cout << "Number of the customer: ";
                    cin >> badge;

                    customer[badge].add_books(books);

                    cout << "Your books were added succesfully!\n";

                    //Waiting sequence
                    int back_procedure_data = 0;

                    do{

                        cout << "\nPress 1 to go back: ";
                        cin >> back_procedure_data;

                    }while(back_procedure_data == 0);

                }

                if(selection_2 == 2){

                    cout << "Number of the customer: ";
                    cin >> badge;

                    customer[badge].return_book();

                    //Waiting sequence
                    int back_procedure_data = 0;

                    do{

                        cout << "\nPress 1 to go back: ";
                        cin >> back_procedure_data;

                    }while(back_procedure_data == 0);

                }
            }while(selection_2 != 3);

        }


    }while(selection_1 != 5);

    cout << "\n\nTerminating the objects" << endl;

    return 0;
}
